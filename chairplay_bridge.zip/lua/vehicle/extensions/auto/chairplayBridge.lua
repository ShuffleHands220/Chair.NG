-- ChairPlay bridge for BeamNG.drive.
--
-- Sends the car you are driving to ChairPlay as two UDP packets, in the same formats as BeamNG's own OutGauge and
-- MotionSim protocols, so ChairPlay needs nothing but its BeamNG switch turned on. With this mod installed you do not
-- have to turn on the protocols in Options > Other > Protocols (and should leave them off, or ChairPlay hears everything
-- twice).
--
-- It is a vehicle extension. BeamNG loads every file in lua/vehicle/extensions/auto/ into every vehicle by itself, and the
-- extension only sends while the player is seated in the vehicle.
--
-- If it does not start on its own, open the console (the ~ key), pick "Current Vehicle" and run:
--     extensions.load('auto_chairplayBridge')

local M = {}

-- ===== What you may change =====
local HOST = "127.0.0.1" -- Where ChairPlay listens: this PC. Use the PC's address if ChairPlay runs on another one.
local OUTGAUGE_PORT = 4444 -- ChairPlay's CHAIRPLAY_BEAMNG_OUTGAUGE_PORT
local MOTION_PORT = 4445 -- ChairPlay's CHAIRPLAY_BEAMNG_MOTION_PORT
local SEND_HZ = 30 -- Packets per second of each kind.
-- ===============================

local TAG = "chairplayBridge"

local ffi = require("ffi")

-- The packets are C structs with the layout BeamNG documents (documentation.beamng.com/modding/protocols). All their
-- fields sit on their natural alignment, so the structs have no padding: 92 and 88 bytes. A reload of this extension
-- defines them again, which ffi refuses, hence the pcall.
pcall(ffi.cdef, [[
typedef struct {
    uint32_t time;
    char car[4];
    uint16_t flags;
    uint8_t gear;
    uint8_t plid;
    float speed;
    float rpm;
    float turbo;
    float engTemp;
    float fuel;
    float oilPressure;
    float oilTemp;
    uint32_t dashLights;
    uint32_t showLights;
    float throttle;
    float brake;
    float clutch;
    char display1[16];
    char display2[16];
} chairplayBridgeOutGauge;

typedef struct {
    char format[4];
    float v[21];
} chairplayBridgeMotion;
]])

-- OutGauge's dash light bits, from Live For Speed. The ones BeamNG leaves out (shift light, pit limiter, hazards, spare
-- and battery here) are not offered.
local DL_FULLBEAM = 2
local DL_HANDBRAKE = 4
local DL_TC = 16
local DL_SIGNAL_L = 32
local DL_SIGNAL_R = 64
local DL_OILWARN = 256
local DL_ABS = 1024
local DL_AVAILABLE = DL_FULLBEAM + DL_HANDBRAKE + DL_TC + DL_SIGNAL_L + DL_SIGNAL_R + DL_OILWARN + DL_ABS

local PSI_TO_BAR = 0.0689476

local outGauge, motion, udp
local sinceSent = 0
local nextSocketTry = 0
local clock = 0
local announced = false
local complained = {}

-- Says a thing once: a problem that repeats at 30 Hz would bury BeamNG's log.
local function complainOnce(key, message)
    if complained[key] then return end
    complained[key] = true
    log("E", TAG, message)
end

-- A number, or the default for anything else (a missing channel, a boolean, NaN).
local function number(value, default)
    if type(value) == "number" and value == value then return value end
    return default or 0
end

-- Electrics values are numbers or booleans depending on the channel: both mean on when not 0 or false.
local function on(value)
    return value ~= nil and value ~= false and value ~= 0
end

-- Whatever the game calls the sockets library, through the names it has been known by.
local function socketLibrary()
    for _, name in ipairs({ "socket", "socket.core", "socket.socket" }) do
        local ok, library = pcall(require, name)
        if ok and type(library) == "table" and library.udp then return library end
    end
    local library = rawget(_G, "socket")
    if type(library) == "table" and library.udp then return library end
    return nil
end

local function openSocket()
    local library = socketLibrary()
    if not library then
        complainOnce("socket", "no UDP socket library found in this BeamNG; nothing is sent to ChairPlay")
        return false
    end
    local ok, created = pcall(library.udp)
    if not ok or not created then
        complainOnce("udp", "cannot create a UDP socket: " .. tostring(created))
        return false
    end
    created:settimeout(0)
    udp = created
    return true
end

local function seated()
    local info = rawget(_G, "playerInfo")
    if info == nil then
        complainOnce("player", "playerInfo is not available in this BeamNG version, so it cannot tell whether you drive this vehicle; nothing is sent")
        return false
    end
    return info.firstPlayerSeated == true
end

-- OutGauge's gear: 0 reverse, 1 neutral, 2 first. Electrics' gearIndex: negative reverse, 0 neutral, 1 first.
local function gearOf(values)
    local index = values.gearIndex
    if type(index) == "number" then
        if index < 0 then return 0 end
        return index + 1
    end
    local shown = values.gear
    if shown == "R" then return 0 end
    local gear = tonumber(shown)
    if gear then return gear + 1 end
    return 1
end

local function fillOutGauge(values)
    local packet = outGauge
    ffi.fill(packet, ffi.sizeof(packet), 0)
    ffi.copy(packet.car, "beam", 4)
    packet.gear = gearOf(values)
    packet.speed = number(values.wheelspeed, number(values.airspeed))
    packet.rpm = number(values.rpmTacho, number(values.rpm))
    packet.turbo = number(values.boost) * PSI_TO_BAR
    packet.engTemp = number(values.watertemp)
    packet.fuel = number(values.fuel)
    packet.oilTemp = number(values.oiltemp)
    packet.throttle = number(values.throttle_input, number(values.throttle))
    packet.brake = number(values.brake_input, number(values.brake))
    packet.clutch = number(values.clutch)

    local lights = 0
    if on(values.highbeam) then lights = lights + DL_FULLBEAM end
    if on(values.parkingbrake) then lights = lights + DL_HANDBRAKE end
    if on(values.tcs) then lights = lights + DL_TC end
    if on(values.signal_L) then lights = lights + DL_SIGNAL_L end
    if on(values.signal_R) then lights = lights + DL_SIGNAL_R end
    if on(values.oil) then lights = lights + DL_OILWARN end
    if on(values.abs) then lights = lights + DL_ABS end
    packet.dashLights = DL_AVAILABLE
    packet.showLights = lights
    return packet
end

-- MotionSim's fields are 21 floats: position, velocity, acceleration and up vector (x, y, z each), then the three
-- angles, their speeds and their accelerations. ChairPlay reads the position and the velocity; the rest is sent as the
-- game would, where this has it.
local function fillMotion()
    local packet = motion
    ffi.fill(packet, ffi.sizeof(packet), 0)
    ffi.copy(packet.format, "BNG1", 4)
    local position = obj:getPosition()
    local velocity = obj:getVelocity()
    packet.v[0], packet.v[1], packet.v[2] = position.x, position.y, position.z
    packet.v[3], packet.v[4], packet.v[5] = velocity.x, velocity.y, velocity.z
    local ok, up = pcall(obj.getDirectionVectorUp, obj)
    if ok and up then
        packet.v[9], packet.v[10], packet.v[11] = up.x, up.y, up.z
    else
        packet.v[11] = 1
    end
    return packet
end

local function send(packet, port)
    udp:sendto(ffi.string(packet, ffi.sizeof(packet)), HOST, port)
end

local function sendBoth()
    local values = electrics and electrics.values
    if not values then return end
    send(fillOutGauge(values), OUTGAUGE_PORT)
    send(fillMotion(), MOTION_PORT)
    if not announced then
        announced = true
        log("I", TAG, "sending this vehicle to ChairPlay at " .. HOST .. " (OutGauge port " .. OUTGAUGE_PORT .. ", MotionSim port " .. MOTION_PORT .. ")")
    end
end

local function update(dt)
    clock = clock + dt
    sinceSent = sinceSent + dt
    if sinceSent < 1 / SEND_HZ then return end
    sinceSent = 0
    if not seated() then return end
    if not udp then
        -- Looked for again every few seconds, not every frame.
        if clock < nextSocketTry then return end
        nextSocketTry = clock + 5
        if not openSocket() then return end
    end
    -- Whatever goes wrong here must not take the vehicle's own update with it.
    local ok, problem = pcall(sendBoth)
    if not ok then complainOnce("send", "could not send to ChairPlay: " .. tostring(problem)) end
end

local function init()
    outGauge = ffi.new("chairplayBridgeOutGauge")
    motion = ffi.new("chairplayBridgeMotion")
    openSocket()
    log("I", TAG, "loaded; it sends while you are seated in this vehicle")
end

local function unload()
    if udp then
        pcall(udp.close, udp)
        udp = nil
    end
end

M.onInit = init
M.updateGFX = update
M.onExtensionUnloaded = unload

return M
